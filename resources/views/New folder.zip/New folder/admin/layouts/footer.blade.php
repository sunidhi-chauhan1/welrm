<!-- footer start -->
<div class="footer">
    <p>Copyright© <script>document.write(new Date().getFullYear())</script> All Rights Reserved By <span class="text-primary">Revel</span></p>
</div>
<!-- footer end -->